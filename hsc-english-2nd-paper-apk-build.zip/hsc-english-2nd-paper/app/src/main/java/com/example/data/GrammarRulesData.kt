package com.example.data

import com.example.model.GrammarRule
import com.example.model.GrammarTopic
import com.example.model.RuleExample

object GrammarRulesData {
    val allRules: List<GrammarRule> = listOf(
        // Prepositions
        GrammarRule(
            id = "prep_1",
            topic = GrammarTopic.PREPOSITION,
            ruleTitle = "Senior, Junior, Superior, Inferior, Prior, Prefer",
            formula = "Adjective of Latin origin + 'to' (NOT 'than')",
            banglaExplanation = "ল্যাটিন কম্পারেটিভ অ্যাডজেক্টিভ (senior, junior, superior, inferior, prior, prefer)-এর পরে সর্বদা 'to' বসে, কখনো 'than' বসে না।",
            examples = listOf(
                RuleExample(
                    context = "Comparison of seniority",
                    incorrectOrPrompt = "He is senior than me.",
                    correct = "He is senior to me.",
                    note = "Always use 'to' after senior."
                ),
                RuleExample(
                    context = "Preference between two things",
                    incorrectOrPrompt = "I prefer milk than tea.",
                    correct = "I prefer milk to tea.",
                    note = "Prefer takes 'to'."
                )
            )
        ),
        GrammarRule(
            id = "prep_2",
            topic = GrammarTopic.PREPOSITION,
            ruleTitle = "Accused of, Guilty of, Deprived of, Congratulate on",
            formula = "Accused/Guilty/Deprived + of | Congratulate + on",
            banglaExplanation = "কোনো অপরাধে অভিযুক্ত বোঝাতে accused/guilty-র সাথে 'of' বসে। অভিনন্দন জানাতে congratulate-এর পর 'on' বসে।",
            examples = listOf(
                RuleExample(
                    context = "Criminal charge",
                    incorrectOrPrompt = "He was accused for theft.",
                    correct = "He was accused of theft.",
                    note = "Accused takes 'of'."
                ),
                RuleExample(
                    context = "Felicitation",
                    incorrectOrPrompt = "We congratulated him for his grand success.",
                    correct = "We congratulated him on his grand success.",
                    note = "Congratulate someone ON an achievement."
                )
            )
        ),
        // Words & Phrases
        GrammarRule(
            id = "sp_words_1",
            topic = GrammarTopic.SPECIAL_WORDS,
            ruleTitle = "Would rather ... than",
            formula = "Subject + would rather + Base Verb + than + Base Verb",
            banglaExplanation = "বরং... তবুও ভালো বুঝাতে 'would rather' ব্যবহৃত হয়। সাধারণত বাক্যে 'than' এর উপস্থিতি থাকে।",
            examples = listOf(
                RuleExample(
                    context = "Choice of honor over dishonor",
                    incorrectOrPrompt = "I ___ starve than beg.",
                    correct = "I would rather starve than beg.",
                    note = "Notice the comparison word 'than'."
                )
            )
        ),
        GrammarRule(
            id = "sp_words_2",
            topic = GrammarTopic.SPECIAL_WORDS,
            ruleTitle = "Had better + V1 (Base Form)",
            formula = "Subject + had better + Base Verb (No 'to')",
            banglaExplanation = "বরং করা ভালো/উচিত বোঝাতে 'had better' বসে। এর পর bare infinitive (মূল ক্রিয়ার base form) বসে।",
            examples = listOf(
                RuleExample(
                    context = "Friendly advice/warning",
                    incorrectOrPrompt = "You have caught a cold. You ___ see a doctor.",
                    correct = "You had better see a doctor.",
                    note = "'had better' implies urgent or practical advice."
                )
            )
        ),
        GrammarRule(
            id = "sp_words_3",
            topic = GrammarTopic.SPECIAL_WORDS,
            ruleTitle = "Let alone (ভাবাই যায় না)",
            formula = "Negative statement + comma + let alone + bigger challenge",
            banglaExplanation = "কোনো ছোট কাজই সম্ভব নয়, দূরের বা বড় কাজের তো প্রশ্নই ওঠে না—এমন ভাব প্রকাশে 'let alone' বসে।",
            examples = listOf(
                RuleExample(
                    context = "Physical inability",
                    incorrectOrPrompt = "He cannot walk a mile, ___ run five miles.",
                    correct = "He cannot walk a mile, let alone run five miles.",
                    note = "Contrasts simpler task with much harder task."
                )
            )
        ),
        GrammarRule(
            id = "sp_words_4",
            topic = GrammarTopic.SPECIAL_WORDS,
            ruleTitle = "What does ... look like? vs What's it like?",
            formula = "What does + Sub + look like? (Appearance) | What's it like + V-ing? (Experience)",
            banglaExplanation = "চেহারা বা বাহ্যিক রূপ জানতে 'What does ... look like?' এবং কোনো কাজের অনুভূতি জানতে 'What's it like + Verb-ing?' বসে।",
            examples = listOf(
                RuleExample(
                    context = "Curiosity about an exotic animal",
                    incorrectOrPrompt = "___ an albatross ___?",
                    correct = "What does an albatross look like?",
                    note = "Double gap asking for appearance."
                ),
                RuleExample(
                    context = "Asking about sensation",
                    incorrectOrPrompt = "___ swimming in the rough ocean?",
                    correct = "What's it like swimming in the rough ocean?",
                    note = "Followed by gerund (V-ing)."
                )
            )
        ),
        // Completing Sentences
        GrammarRule(
            id = "cs_1",
            topic = GrammarTopic.COMPLETING_SENTENCES,
            ruleTitle = "Lest (পাছে ভয় হয় যে)",
            formula = "Clause + lest + Subject + should/might + Base Verb",
            banglaExplanation = "Lest যুক্ত ক্লজে Subject-এর পরে অবশ্যই 'should' (বা 'might') এবং ক্রিয়ার base form বসে। এতে কোনো negative শব্দ বসে না।",
            examples = listOf(
                RuleExample(
                    context = "Hurry up",
                    incorrectOrPrompt = "Walk fast lest you ___ the train.",
                    correct = "Walk fast lest you should miss the train.",
                    note = "Subject + should + V1."
                )
            )
        ),
        GrammarRule(
            id = "cs_2",
            topic = GrammarTopic.COMPLETING_SENTENCES,
            ruleTitle = "It is high time / It is time",
            formula = "It is high time + Subject + Past Indefinite (V2) OR (for + obj + to-infinitive)",
            banglaExplanation = "কোনো কাজ করার উপযুক্ত সময় ইতিমধ্যে পার হয়ে গেছে, তাই কালবিলম্ব না করে এখনই করা উচিত বোঝাতে 'It is high time'-এর পরে Past Indefinite tense বসে।",
            examples = listOf(
                RuleExample(
                    context = "Reforming bad habit",
                    incorrectOrPrompt = "Corruption is widespread. It is high time we ___ our society.",
                    correct = "It is high time we reformed our society.",
                    note = "Past form 'reformed' must be used after Subject."
                )
            )
        ),
        GrammarRule(
            id = "cs_3",
            topic = GrammarTopic.COMPLETING_SENTENCES,
            ruleTitle = "Conditionals (1st, 2nd, and 3rd)",
            formula = "1st: If + Present, Future (will + V1) | 2nd: If + Past Indef., would + V1 | 3rd: If + Past Perfect, would have + V3",
            banglaExplanation = "শর্তযুক্ত বাক্যের তিনটি রূপ: ১ম এ Future (will), ২য় এ conditional (would + base verb), এবং ৩য় এ (would have + V3) বসে।",
            examples = listOf(
                RuleExample(
                    context = "Third conditional board question",
                    incorrectOrPrompt = "If I had seen him earlier, I ___ (tell) him the news.",
                    correct = "If I had seen him earlier, I would have told him the news.",
                    note = "Past perfect requires 'would have + V3'."
                )
            )
        ),
        // Right Form of Verbs
        GrammarRule(
            id = "rfv_1",
            topic = GrammarTopic.RIGHT_FORM_OF_VERBS,
            ruleTitle = "Along with, As well as, Accompanied by, In addition to",
            formula = "Subject 1 + (along with / as well as) + Subject 2 + Verb (according to Subject 1)",
            banglaExplanation = "যদি দুটি Subject 'as well as', 'along with', 'together with', 'accompanied by' দ্বারা যুক্ত হয়, তবে Verb প্রথম Subject অনুসারে হয়।",
            examples = listOf(
                RuleExample(
                    context = "Teacher and students",
                    incorrectOrPrompt = "The teacher, along with his students, were present.",
                    correct = "The teacher, along with his students, was present.",
                    note = "First subject 'teacher' is singular, so verb is 'was'."
                )
            )
        ),
        GrammarRule(
            id = "rfv_2",
            topic = GrammarTopic.RIGHT_FORM_OF_VERBS,
            ruleTitle = "Look forward to, With a view to, Mind, Cannot help",
            formula = "Prepositional phrase ending in 'to' (exception) + Verb-ing",
            banglaExplanation = "'with a view to', 'look forward to', 'get used to', 'would you mind', 'cannot help'-এর পরে verb-এর সাথে 'ing' যুক্ত হয়।",
            examples = listOf(
                RuleExample(
                    context = "Letter closing",
                    incorrectOrPrompt = "I am looking forward to hear from you.",
                    correct = "I am looking forward to hearing from you.",
                    note = "'looking forward to' + V-ing."
                )
            )
        ),
        // Narration
        GrammarRule(
            id = "nar_1",
            topic = GrammarTopic.NARRATION,
            ruleTitle = "Interrogative Sentence Narration",
            formula = "Subject + asked + (if / whether OR Wh-word) + Sub + Assertive Tense",
            banglaExplanation = "প্রশ্নবোধক বাক্যে reporting verb 'said to' পরিবর্তিত হয়ে 'asked' হয়। Yes/No প্রশ্নে linking word 'if' বা 'whether' বসে, Wh-প্রশ্নে Wh-শব্দটি অপরিবর্তিত থাকে এবং বাক্যটি assertive হয়ে যায়।",
            examples = listOf(
                RuleExample(
                    context = "Direct speech conversion",
                    incorrectOrPrompt = "He said to me, 'Are you going to college today?'",
                    correct = "He asked me if I was going to college that day.",
                    note = "Tense changes to past continuous, order becomes assertive."
                )
            )
        ),
        // Modifiers
        GrammarRule(
            id = "mod_1",
            topic = GrammarTopic.MODIFIERS,
            ruleTitle = "Pre-modify the noun vs Post-modify the noun",
            formula = "Adjective / Participle / Noun-adjective + Noun OR Noun + (Infinitive phrase / Appositive)",
            banglaExplanation = "Pre-modifier হিসেবে সাধারণত adjective, present participle (V-ing), past participle (V3), বা noun-adjective ব্যবহৃত হয়। Post-modifier হিসেবে infinitive phrase (to + V1), prepositional phrase, বা appositive ব্যবহৃত হয়।",
            examples = listOf(
                RuleExample(
                    context = "Board exam passage blank",
                    incorrectOrPrompt = "Kazi Nazrul Islam, ___ (use an appositive to post-modify the noun), wrote inspiring poems.",
                    correct = "our national poet / a great rebel poet",
                    note = "An appositive gives additional identity without a verb."
                )
            )
        ),
        // Sentence Connectors
        GrammarRule(
            id = "conn_1",
            topic = GrammarTopic.SENTENCE_CONNECTORS,
            ruleTitle = "Contrast Connectors vs Cause & Effect Connectors",
            formula = "Contrast: However, On the contrary, Nevertheless | Result: Therefore, Consequently, As a result",
            banglaExplanation = "বিপরীত ভাব প্রকাশে 'However', 'On the other hand', 'Nevertheless' বসে। ফলাফল বোঝাতে 'Therefore', 'As a result', 'Consequently' বসে।",
            examples = listOf(
                RuleExample(
                    context = "Linking ideas logically",
                    incorrectOrPrompt = "He studied hard. ___, he could not obtain GPA 5.",
                    correct = "However / Unfortunately",
                    note = "Expresses contrasting outcome to hard work."
                )
            )
        ),
        // Synonyms & Antonyms
        GrammarRule(
            id = "syn_1",
            topic = GrammarTopic.SYNONYM_ANTONYM,
            ruleTitle = "Contextual Word Classes in HSC",
            formula = "Noun -> Noun synonym | Adjective -> Adjective synonym | Verb -> Verb synonym",
            banglaExplanation = "যে word-এর synonym বা antonym চাওয়া হয়েছে, সেটির grammatical part of speech রক্ষা করা বাধ্যতামূলক। Noun-এর বিপরীত noun, Adjective-এর সমার্থক adjective হতে হবে।",
            examples = listOf(
                RuleExample(
                    context = "Exam standard word",
                    incorrectOrPrompt = "Synonym of 'Fragile' (Adjective)",
                    correct = "Delicate / Brittle / Breakable",
                    note = "Must be an adjective, not a noun like 'fragility'."
                )
            )
        )
    )
}
