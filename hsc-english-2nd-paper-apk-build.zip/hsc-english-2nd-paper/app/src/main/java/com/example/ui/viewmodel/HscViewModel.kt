package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GrammarRulesData
import com.example.data.PracticeRepository
import com.example.data.UserStats
import com.example.model.BoardExamSet
import com.example.model.GrammarRule
import com.example.model.GrammarTopic
import com.example.model.Question
import com.example.model.QuizResult
import com.example.model.Screen
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ActiveQuizState(
    val title: String = "",
    val topic: GrammarTopic? = null,
    val isExamMode: Boolean = false,
    val questions: List<Question> = emptyList(),
    val currentIndex: Int = 0,
    val selectedAnswers: MutableMap<Int, Int> = mutableMapOf(), // questionIndex -> optionIndex
    val isAnswerRevealedForCurrent: Boolean = false, // In practice mode
    val remainingSeconds: Int = 0,
    val bookmarkedIds: Set<String> = emptySet(),
    val examSubmitted: Boolean = false
) {
    val currentQuestion: Question?
        get() = questions.getOrNull(currentIndex)

    val progressRatio: Float
        get() = if (questions.isNotEmpty()) (currentIndex + 1).toFloat() / questions.size else 0f
}

class HscViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PracticeRepository(application)
    private val worksheetRepository = com.example.data.WorksheetRepository(application)

    private val screenStack = mutableListOf<Screen>(Screen.Home)
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _userStats = MutableStateFlow(repository.getUserStats())
    val userStats: StateFlow<UserStats> = _userStats.asStateFlow()

    private val _activeQuiz = MutableStateFlow(ActiveQuizState())
    val activeQuiz: StateFlow<ActiveQuizState> = _activeQuiz.asStateFlow()

    // Rules screen state
    private val _selectedRuleTopic = MutableStateFlow<GrammarTopic?>(null)
    val selectedRuleTopic: StateFlow<GrammarTopic?> = _selectedRuleTopic.asStateFlow()

    private val _ruleSearchQuery = MutableStateFlow("")
    val ruleSearchQuery: StateFlow<String> = _ruleSearchQuery.asStateFlow()

    // Custom code hub message
    private val _customHubMessage = MutableStateFlow<String?>(null)
    val customHubMessage: StateFlow<String?> = _customHubMessage.asStateFlow()

    private var timerJob: Job? = null

    fun navigateTo(screen: Screen) {
        screenStack.add(screen)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.lastIndex)
            _currentScreen.value = screenStack.last()
            refreshStats()
            return true
        }
        return false
    }

    fun refreshStats() {
        _userStats.value = repository.getUserStats()
    }

    // Start Topic-wise Practice
    fun startTopicPractice(topic: GrammarTopic) {
        val questions = repository.getQuestionsForTopic(topic).ifEmpty {
            repository.getAllQuestions()
        }
        _activeQuiz.value = ActiveQuizState(
            title = topic.title,
            topic = topic,
            isExamMode = false,
            questions = questions,
            currentIndex = 0,
            selectedAnswers = mutableMapOf(),
            isAnswerRevealedForCurrent = false,
            remainingSeconds = 0,
            bookmarkedIds = repository.getBookmarkedQuestionIds()
        )
        navigateTo(Screen.Practice(topic))
    }

    // Start Board Exam Mock
    fun startBoardExam(examSetId: String) {
        val examSet = repository.getExamSet(examSetId) ?: return
        val totalSecs = examSet.durationMinutes * 60

        _activeQuiz.value = ActiveQuizState(
            title = examSet.title,
            topic = null,
            isExamMode = true,
            questions = examSet.questions,
            currentIndex = 0,
            selectedAnswers = mutableMapOf(),
            isAnswerRevealedForCurrent = false,
            remainingSeconds = totalSecs,
            bookmarkedIds = repository.getBookmarkedQuestionIds()
        )

        startTimer()
        navigateTo(Screen.BoardExam(examSetId))
    }

    // Start practice on Bookmarked or Mistake Questions
    fun startReviewPractice(isMistakes: Boolean) {
        val questions = if (isMistakes) {
            repository.getMistakeQuestions()
        } else {
            repository.getBookmarkedQuestions()
        }

        if (questions.isEmpty()) return

        val title = if (isMistakes) "Mistakes Review" else "Bookmarked Questions"
        _activeQuiz.value = ActiveQuizState(
            title = title,
            topic = null,
            isExamMode = false,
            questions = questions,
            currentIndex = 0,
            selectedAnswers = mutableMapOf(),
            isAnswerRevealedForCurrent = false,
            remainingSeconds = 0,
            bookmarkedIds = repository.getBookmarkedQuestionIds()
        )
        navigateTo(Screen.Practice(GrammarTopic.PREPOSITION))
    }

    fun selectOption(optionIndex: Int) {
        val current = _activeQuiz.value
        val qIndex = current.currentIndex
        val question = current.currentQuestion ?: return

        val newAnswers = current.selectedAnswers.toMutableMap()
        newAnswers[qIndex] = optionIndex

        if (current.isExamMode) {
            _activeQuiz.value = current.copy(selectedAnswers = newAnswers)
        } else {
            // In practice mode, instant feedback & recording
            val isCorrect = (optionIndex == question.correctIndex)
            repository.recordQuestionAttempt(question.id, isCorrect)
            refreshStats()

            _activeQuiz.value = current.copy(
                selectedAnswers = newAnswers,
                isAnswerRevealedForCurrent = true
            )
        }
    }

    fun nextQuestion() {
        val current = _activeQuiz.value
        if (current.currentIndex < current.questions.lastIndex) {
            _activeQuiz.value = current.copy(
                currentIndex = current.currentIndex + 1,
                isAnswerRevealedForCurrent = current.selectedAnswers.containsKey(current.currentIndex + 1)
            )
        }
    }

    fun previousQuestion() {
        val current = _activeQuiz.value
        if (current.currentIndex > 0) {
            _activeQuiz.value = current.copy(
                currentIndex = current.currentIndex - 1,
                isAnswerRevealedForCurrent = current.selectedAnswers.containsKey(current.currentIndex - 1)
            )
        }
    }

    fun jumpToQuestion(index: Int) {
        val current = _activeQuiz.value
        if (index in 0..current.questions.lastIndex) {
            _activeQuiz.value = current.copy(
                currentIndex = index,
                isAnswerRevealedForCurrent = current.selectedAnswers.containsKey(index)
            )
        }
    }

    fun toggleCurrentBookmark() {
        val current = _activeQuiz.value
        val question = current.currentQuestion ?: return
        val isNowBookmarked = repository.toggleBookmark(question.id)

        val newSet = current.bookmarkedIds.toMutableSet()
        if (isNowBookmarked) newSet.add(question.id) else newSet.remove(question.id)
        _activeQuiz.value = current.copy(bookmarkedIds = newSet)
        refreshStats()
    }

    fun isQuestionBookmarked(questionId: String): Boolean {
        return _activeQuiz.value.bookmarkedIds.contains(questionId) || repository.isBookmarked(questionId)
    }

    fun submitExam() {
        timerJob?.cancel()
        val current = _activeQuiz.value
        val questions = current.questions
        val userAnswers = current.selectedAnswers

        var correct = 0
        var wrong = 0
        var skipped = 0
        val topicMap = mutableMapOf<GrammarTopic, Pair<Int, Int>>() // correct, total

        questions.forEachIndexed { idx, q ->
            val sel = userAnswers[idx]
            val isCorrect = sel == q.correctIndex
            if (sel != null) {
                repository.recordQuestionAttempt(q.id, isCorrect)
                if (isCorrect) correct++ else wrong++
            } else {
                skipped++
            }

            val curTopic = topicMap[q.topic] ?: Pair(0, 0)
            topicMap[q.topic] = Pair(
                curTopic.first + (if (isCorrect) 1 else 0),
                curTopic.second + 1
            )
        }

        refreshStats()

        val percentage = if (questions.isNotEmpty()) (correct * 100f) / questions.size else 0f
        val result = QuizResult(
            title = current.title,
            totalQuestions = questions.size,
            correctCount = correct,
            wrongCount = wrong,
            skippedCount = skipped,
            scorePercentage = percentage,
            topicBreakdown = topicMap,
            questions = questions,
            userAnswers = userAnswers
        )

        _activeQuiz.value = current.copy(examSubmitted = true)
        navigateTo(Screen.Result(result))
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_activeQuiz.value.remainingSeconds > 0) {
                delay(1000)
                val remaining = _activeQuiz.value.remainingSeconds - 1
                _activeQuiz.value = _activeQuiz.value.copy(remainingSeconds = remaining)
                if (remaining <= 0) {
                    submitExam()
                    break
                }
            }
        }
    }

    // Rules Filtering
    fun selectRuleTopic(topic: GrammarTopic?) {
        _selectedRuleTopic.value = topic
    }

    fun setRuleSearchQuery(query: String) {
        _ruleSearchQuery.value = query
    }

    fun getFilteredRules(): List<GrammarRule> {
        val topic = _selectedRuleTopic.value
        val query = _ruleSearchQuery.value.trim().lowercase()

        return GrammarRulesData.allRules.filter { rule ->
            (topic == null || rule.topic == topic) &&
                (query.isEmpty() ||
                    rule.ruleTitle.lowercase().contains(query) ||
                    rule.formula.lowercase().contains(query) ||
                    rule.banglaExplanation.lowercase().contains(query))
        }
    }

    // Custom Code & Question Management
    fun getCustomQuestions(): List<Question> = repository.getCustomQuestions()

    fun deleteCustomQuestion(id: String) {
        repository.deleteCustomQuestion(id)
        refreshStats()
    }

    fun importQuestionsFromJson(jsonText: String) {
        val (count, msg) = repository.importQuestionsFromJson(jsonText)
        _customHubMessage.value = msg
        refreshStats()
    }

    fun addSingleCustomQuestion(
        topic: GrammarTopic,
        questionText: String,
        options: List<String>,
        correctIndex: Int,
        explanation: String
    ) {
        val q = Question(
            id = "custom_${System.currentTimeMillis()}",
            topic = topic,
            questionText = questionText,
            options = options,
            correctIndex = correctIndex,
            explanation = explanation,
            boardTag = "Custom Added",
            isCustom = true
        )
        repository.addCustomQuestion(q)
        _customHubMessage.value = "Question added successfully!"
        refreshStats()
    }

    fun clearCustomHubMessage() {
        _customHubMessage.value = null
    }

    fun getAllBoardSets(): List<BoardExamSet> = repository.getAllBoardSets()

    fun getBookmarkedQuestions(): List<Question> = repository.getBookmarkedQuestions()

    fun getMistakeQuestions(): List<Question> = repository.getMistakeQuestions()

    fun getWorksheets(topic: GrammarTopic): List<com.example.model.PassageWorksheet> {
        return worksheetRepository.getWorksheets(topic)
    }

    fun getWorksheetCounts(): Map<GrammarTopic, Int> {
        return worksheetRepository.getWorksheetCounts()
    }

    fun startWorksheet(topic: GrammarTopic, passageIndex: Int = 0) {
        navigateTo(Screen.WorksheetView(topic, passageIndex))
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
