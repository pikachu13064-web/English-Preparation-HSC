package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors
val PrimaryBlue = Color(0xFF1E3A8A)
val OnPrimaryBlue = Color(0xFFFFFFFF)
val PrimaryBlueContainer = Color(0xFFDBEAFE)
val OnPrimaryBlueContainer = Color(0xFF1E3A8A)

val SecondaryTeal = Color(0xFF0D9488)
val OnSecondaryTeal = Color(0xFFFFFFFF)
val SecondaryTealContainer = Color(0xFFCCFBF1)
val OnSecondaryTealContainer = Color(0xFF115E59)

val TertiaryAmber = Color(0xFFD97706)
val OnTertiaryAmber = Color(0xFFFFFFFF)
val TertiaryAmberContainer = Color(0xFFFEF3C7)
val OnTertiaryAmberContainer = Color(0xFF92400E)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

val CorrectGreen = Color(0xFF16A34A)
val CorrectGreenContainer = Color(0xFFDCFCE7)
val WrongRed = Color(0xFFDC2626)
val WrongRedContainer = Color(0xFFFEE2E2)

// Dark Scheme Colors
val DarkPrimaryBlue = Color(0xFF93C5FD)
val DarkOnPrimaryBlue = Color(0xFF172554)
val DarkPrimaryBlueContainer = Color(0xFF1E3A8A)
val DarkOnPrimaryBlueContainer = Color(0xFFDBEAFE)

val DarkSecondaryTeal = Color(0xFF5EEAD4)
val DarkOnSecondaryTeal = Color(0xFF134E4A)
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF475569)
