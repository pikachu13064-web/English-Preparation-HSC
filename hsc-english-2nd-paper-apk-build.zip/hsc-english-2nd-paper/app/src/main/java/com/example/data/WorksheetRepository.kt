package com.example.data

import android.content.Context
import com.example.model.GrammarTopic
import com.example.model.PassageBlank
import com.example.model.PassageWorksheet
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader

class WorksheetRepository(private val context: Context) {
    private val cache = mutableMapOf<GrammarTopic, List<PassageWorksheet>>()

    fun getWorksheets(topic: GrammarTopic): List<PassageWorksheet> {
        cache[topic]?.let { return it }

        val assetName = when (topic) {
            GrammarTopic.ARTICLE -> "worksheets/articles.json"
            GrammarTopic.RIGHT_FORM_OF_VERBS -> "worksheets/verbs.json"
            GrammarTopic.PREPOSITION -> "worksheets/prepositions.json"
            GrammarTopic.SENTENCE_CONNECTORS -> "worksheets/connectors.json"
            else -> null
        } ?: return emptyList()

        val list = loadFromAsset(assetName, topic)
        cache[topic] = list
        return list
    }

    fun getAllWorksheetTopics(): List<GrammarTopic> {
        return listOf(
            GrammarTopic.PREPOSITION,
            GrammarTopic.RIGHT_FORM_OF_VERBS,
            GrammarTopic.SENTENCE_CONNECTORS,
            GrammarTopic.ARTICLE
        )
    }

    fun getWorksheetCounts(): Map<GrammarTopic, Int> {
        return mapOf(
            GrammarTopic.PREPOSITION to getWorksheets(GrammarTopic.PREPOSITION).size,
            GrammarTopic.RIGHT_FORM_OF_VERBS to getWorksheets(GrammarTopic.RIGHT_FORM_OF_VERBS).size,
            GrammarTopic.SENTENCE_CONNECTORS to getWorksheets(GrammarTopic.SENTENCE_CONNECTORS).size,
            GrammarTopic.ARTICLE to getWorksheets(GrammarTopic.ARTICLE).size
        )
    }

    private fun loadFromAsset(filename: String, topic: GrammarTopic): List<PassageWorksheet> {
        val result = mutableListOf<PassageWorksheet>()
        try {
            val inputStream = context.assets.open(filename)
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
            val jsonString = reader.use { it.readText() }
            val array = JSONArray(jsonString)

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val blanksArr = obj.getJSONArray("blanks")
                val blanks = mutableListOf<PassageBlank>()

                for (j in 0 until blanksArr.length()) {
                    val bObj = blanksArr.getJSONObject(j)
                    blanks.add(
                        PassageBlank(
                            letter = bObj.getString("letter"),
                            prompt = bObj.optString("prompt").takeIf { it.isNotEmpty() },
                            answer = bObj.getString("answer"),
                            explanation = bObj.getString("explanation")
                        )
                    )
                }

                result.add(
                    PassageWorksheet(
                        id = obj.getString("id"),
                        questionNumber = obj.getInt("questionNumber"),
                        topic = topic,
                        sourceBoard = obj.getString("sourceBoard"),
                        rawText = obj.getString("rawText"),
                        blanks = blanks
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }
}
