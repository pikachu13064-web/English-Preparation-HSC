package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GrammarTopic
import com.example.model.PassageBlank
import com.example.model.PassageWorksheet
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenContainer
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueContainer
import com.example.ui.theme.SecondaryTeal
import com.example.ui.theme.TertiaryAmber
import com.example.ui.viewmodel.HscViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WorksheetPracticeScreen(
    topic: GrammarTopic,
    initialIndex: Int = 0,
    viewModel: HscViewModel,
    modifier: Modifier = Modifier
) {
    val worksheets = remember(topic) { viewModel.getWorksheets(topic) }
    var currentIndex by remember(topic) { mutableIntStateOf(initialIndex.coerceIn(0, (worksheets.size - 1).coerceAtLeast(0))) }

    val currentWorksheet = worksheets.getOrNull(currentIndex)
    // Map of blank letter -> isRevealed
    val revealedMap = remember(currentIndex) { mutableStateMapOf<String, Boolean>() }
    var selectedBlankLetter by remember(currentIndex) { mutableStateOf<String?>(null) }

    val totalBlanks = currentWorksheet?.blanks?.size ?: 0
    val revealedCount = revealedMap.values.count { it }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "${topic.title} Worksheet",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        currentWorksheet?.let { ws ->
                            Text(
                                text = "Q. ${ws.questionNumber} • ${ws.sourceBoard}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("worksheet_back_btn")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Reveal / Hide All Actions
                    IconButton(
                        onClick = {
                            val allRevealed = (revealedCount == totalBlanks)
                            currentWorksheet?.blanks?.forEach { b ->
                                revealedMap[b.letter] = !allRevealed
                            }
                        },
                        modifier = Modifier.testTag("toggle_reveal_all_btn")
                    ) {
                        Icon(
                            imageVector = if (revealedCount == totalBlanks) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle Reveal All",
                            tint = PrimaryBlue
                        )
                    }

                    // Revealed counter badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (revealedCount == totalBlanks) CorrectGreenContainer else PrimaryBlueContainer,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = "$revealedCount / $totalBlanks",
                            color = if (revealedCount == totalBlanks) CorrectGreen else PrimaryBlue,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            if (currentIndex > 0) currentIndex--
                        },
                        enabled = currentIndex > 0,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Prev Board")
                    }

                    Text(
                        text = "${currentIndex + 1} / ${worksheets.size}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            if (currentIndex < worksheets.lastIndex) currentIndex++
                        },
                        enabled = currentIndex < worksheets.lastIndex,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Next Board")
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Quick Board Selector Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(worksheets) { index, ws ->
                    val isSelected = index == currentIndex
                    Surface(
                        onClick = { currentIndex = index },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = "Q${ws.questionNumber}: ${ws.sourceBoard.split(';')[0].trim()}",
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            if (currentWorksheet != null) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Tip banner
                    item {
                        Surface(
                            color = PrimaryBlueContainer.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Tap on any [a]...[n] gap below to reveal the answer and its detailed Bengali grammar rule!",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PrimaryBlue
                                )
                            }
                        }
                    }

                    // Interactive Passage Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = SecondaryTeal.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = currentWorksheet.sourceBoard,
                                            color = SecondaryTeal,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }

                                    Text(
                                        text = "${currentWorksheet.blanks.size} Gaps",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Parse and render text with interactive buttons
                                InteractivePassageFlow(
                                    rawText = currentWorksheet.rawText,
                                    blanks = currentWorksheet.blanks,
                                    revealedMap = revealedMap,
                                    selectedLetter = selectedBlankLetter,
                                    onBlankClick = { letter ->
                                        val cur = revealedMap[letter] ?: false
                                        revealedMap[letter] = !cur
                                        selectedBlankLetter = letter
                                    }
                                )
                            }
                        }
                    }

                    // Active Selected Explanation Banner
                    selectedBlankLetter?.let { letter ->
                        val blank = currentWorksheet.blanks.find { it.letter == letter }
                        if (blank != null) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = PrimaryBlue),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    color = TertiaryAmber,
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "(${blank.letter})",
                                                        color = Color.White,
                                                        fontWeight = FontWeight.Bold,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "Answer: ${blank.answer}",
                                                    color = Color.White,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Text(
                                            text = blank.explanation,
                                            color = Color.White.copy(alpha = 0.95f),
                                            style = MaterialTheme.typography.bodyMedium,
                                            lineHeight = 22.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Full Answer Sheet & Explanation List
                    item {
                        Text(
                            text = "📋 Complete Answer Sheet & Explanations",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    itemsIndexed(currentWorksheet.blanks) { _, blank ->
                        val isRevealed = revealedMap[blank.letter] == true
                        val isSelected = selectedBlankLetter == blank.letter

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    revealedMap[blank.letter] = true
                                    selectedBlankLetter = blank.letter
                                },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) PrimaryBlueContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = if (isSelected) PrimaryBlue else PrimaryBlueContainer,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = "(${blank.letter})",
                                                color = if (isSelected) Color.White else PrimaryBlue,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Text(
                                            text = "Answer: ${blank.answer}",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    if (isRevealed) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Revealed",
                                            tint = CorrectGreen,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = blank.explanation,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 20.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Parses raw text containing {a} or {a}(verb) and renders words and gap chips
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun InteractivePassageFlow(
    rawText: String,
    blanks: List<PassageBlank>,
    revealedMap: Map<String, Boolean>,
    selectedLetter: String?,
    onBlankClick: (String) -> Unit
) {
    // Regex matches {a} or {a}(verb)
    val regex = Regex("""\{([a-n])\}(?:\(([^)]*)\))?""")
    val tokens = mutableListOf<PassageToken>()

    var lastIndex = 0
    regex.findAll(rawText).forEach { match ->
        if (match.range.first > lastIndex) {
            val textSegment = rawText.substring(lastIndex, match.range.first)
            tokens.add(PassageToken.Text(textSegment))
        }
        val letter = match.groupValues[1]
        val prompt = match.groupValues[2].takeIf { it.isNotEmpty() }
        tokens.add(PassageToken.Blank(letter, prompt))
        lastIndex = match.range.last + 1
    }
    if (lastIndex < rawText.length) {
        tokens.add(PassageToken.Text(rawText.substring(lastIndex)))
    }

    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalArrangement = Arrangement.Center
    ) {
        tokens.forEach { token ->
            when (token) {
                is PassageToken.Text -> {
                    // Split by spaces so word wrapping is natural
                    val words = token.content.split(" ")
                    words.forEachIndexed { idx, word ->
                        if (word.isNotEmpty()) {
                            Text(
                                text = if (idx < words.size - 1) "$word " else word,
                                style = MaterialTheme.typography.bodyLarge,
                                lineHeight = 30.sp,
                                modifier = Modifier.align(Alignment.CenterVertically)
                            )
                        }
                    }
                }
                is PassageToken.Blank -> {
                    val isRevealed = revealedMap[token.letter] == true
                    val isSelected = selectedLetter == token.letter
                    val blankInfo = blanks.find { it.letter == token.letter }
                    val answerText = blankInfo?.answer?.split('/')?.firstOrNull() ?: ""

                    Surface(
                        onClick = { onBlankClick(token.letter) },
                        shape = RoundedCornerShape(6.dp),
                        color = when {
                            isRevealed -> CorrectGreenContainer
                            isSelected -> PrimaryBlueContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        border = BorderStroke(
                            1.5.dp,
                            when {
                                isRevealed -> CorrectGreen
                                isSelected -> PrimaryBlue
                                else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            }
                        ),
                        modifier = Modifier
                            .padding(horizontal = 2.dp, vertical = 2.dp)
                            .align(Alignment.CenterVertically)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isRevealed) answerText else "[${token.letter}]",
                                fontWeight = FontWeight.Bold,
                                color = if (isRevealed) CorrectGreen else if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp
                            )
                            if (token.prompt != null) {
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "(${token.prompt})",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                    Text(text = " ", style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

private sealed class PassageToken {
    data class Text(val content: String) : PassageToken()
    data class Blank(val letter: String, val prompt: String?) : PassageToken()
}
