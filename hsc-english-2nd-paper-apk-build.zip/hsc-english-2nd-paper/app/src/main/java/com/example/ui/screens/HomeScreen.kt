package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BoardExamSet
import com.example.model.GrammarTopic
import com.example.model.Screen
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.SecondaryTeal
import com.example.ui.theme.TertiaryAmber
import com.example.ui.theme.WrongRed
import com.example.ui.viewmodel.HscViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HscViewModel,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.userStats.collectAsState()
    val boardSets = viewModel.getAllBoardSets()

    ScaffoldWithTopBar(viewModel = viewModel, modifier = modifier) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Hero Banner
            item {
                HeroBannerSection(viewModel = viewModel)
            }

            // Quick Stats Row
            item {
                QuickStatsSection(stats = stats, viewModel = viewModel)
            }

            // Action Shortcuts
            item {
                ActionShortcutsSection(viewModel = viewModel)
            }

            // Section: Official Board Interactive Worksheets
            item {
                SectionHeader(
                    title = "Board Interactive Worksheets",
                    subtitle = "108 authentic board passages with tap-to-reveal answers & Bengali rules",
                    actionText = null,
                    onActionClick = null
                )
            }

            item {
                BoardWorksheetsGridSection(viewModel = viewModel)
            }

            // Section: Topic-wise Practice
            item {
                SectionHeader(
                    title = "Grammar Topics (Syllabus)",
                    subtitle = "Official HSC English 2nd Paper items with instant rule hints",
                    actionText = "All Rules",
                    onActionClick = { viewModel.navigateTo(Screen.RulesBook) }
                )
            }

            items(GrammarTopic.values().toList().chunked(2)) { topicPair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    for (topic in topicPair) {
                        TopicCard(
                            topic = topic,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.startTopicPractice(topic) }
                        )
                    }
                    if (topicPair.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            // Section: Board Exam Model Tests
            item {
                Spacer(modifier = Modifier.height(16.dp))
                SectionHeader(
                    title = "Board Question Mock Tests",
                    subtitle = "Simulate real exam timing and question patterns",
                    actionText = null,
                    onActionClick = null
                )
            }

            items(boardSets) { examSet ->
                BoardExamSetCard(
                    examSet = examSet,
                    onClick = { viewModel.startBoardExam(examSet.id) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScaffoldWithTopBar(
    viewModel: HscViewModel,
    modifier: Modifier = Modifier,
    content: @Composable (PaddingValues) -> Unit
) {
    androidx.compose.material3.Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "A+",
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "HSC English 2nd Paper",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Examinee Prep & Practice",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.RulesBook) },
                        modifier = Modifier.testTag("action_rules_book")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Grammar Rules",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.BookmarksAndMistakes) },
                        modifier = Modifier.testTag("action_bookmarks")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Saved Questions",
                            tint = TertiaryAmber
                        )
                    }
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.CustomCodeHub) },
                        modifier = Modifier.testTag("action_code_hub")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = "Code & Custom Questions",
                            tint = SecondaryTeal
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        content = content
    )
}

@Composable
private fun HeroBannerSection(viewModel: HscViewModel) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.hsc_banner),
                contentDescription = "HSC English Study Banner",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Gradient Overlay for readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xCC0F172A),
                                Color(0xEE0F172A)
                            ),
                            startY = 60f
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = TertiaryAmber,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "HSC 2024-2026",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Target GPA 5.00 / A+",
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Master Grammar Part A (60 Marks)",
                    color = Color.White,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.startBoardExam("set_dhaka_2023") },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("hero_start_mock_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Start Dhaka Board Mock", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(Screen.RulesBook) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("hero_rules_btn")
                    ) {
                        Text("Quick Rules", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickStatsSection(
    stats: com.example.data.UserStats,
    viewModel: HscViewModel
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatBadgeCard(
            label = "Attempted",
            value = "${stats.totalAnswered}",
            icon = Icons.Default.Assignment,
            iconTint = PrimaryBlue,
            modifier = Modifier.weight(1f)
        )
        StatBadgeCard(
            label = "Accuracy",
            value = "${stats.accuracyPercentage}%",
            icon = Icons.Default.TrendingUp,
            iconTint = CorrectGreen,
            modifier = Modifier.weight(1f)
        )
        StatBadgeCard(
            label = "Mistakes",
            value = "${stats.mistakesCount}",
            icon = Icons.Outlined.ErrorOutline,
            iconTint = WrongRed,
            modifier = Modifier
                .weight(1f)
                .clickable {
                    if (stats.mistakesCount > 0) {
                        viewModel.startReviewPractice(isMistakes = true)
                    } else {
                        viewModel.navigateTo(Screen.BookmarksAndMistakes)
                    }
                }
        )
    }
}

@Composable
private fun StatBadgeCard(
    label: String,
    value: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        )
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ActionShortcutsSection(viewModel: HscViewModel) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            ShortcutChip(
                label = "Prepositions (30)",
                icon = Icons.Default.MenuBook,
                color = PrimaryBlue,
                onClick = { viewModel.startWorksheet(GrammarTopic.PREPOSITION) }
            )
        }
        item {
            ShortcutChip(
                label = "Verbs (15)",
                icon = Icons.Default.MenuBook,
                color = SecondaryTeal,
                onClick = { viewModel.startWorksheet(GrammarTopic.RIGHT_FORM_OF_VERBS) }
            )
        }
        item {
            ShortcutChip(
                label = "Connectors (42)",
                icon = Icons.Default.MenuBook,
                color = TertiaryAmber,
                onClick = { viewModel.startWorksheet(GrammarTopic.SENTENCE_CONNECTORS) }
            )
        }
        item {
            ShortcutChip(
                label = "Articles (21)",
                icon = Icons.Default.MenuBook,
                color = CorrectGreen,
                onClick = { viewModel.startWorksheet(GrammarTopic.ARTICLE) }
            )
        }
        item {
            ShortcutChip(
                label = "All Board Grand Test",
                icon = Icons.Default.Timer,
                color = PrimaryBlue,
                onClick = { viewModel.startBoardExam("set_all_boards_grand") }
            )
        }
        item {
            ShortcutChip(
                label = "Saved & Mistakes",
                icon = Icons.Default.Bookmark,
                color = TertiaryAmber,
                onClick = { viewModel.navigateTo(Screen.BookmarksAndMistakes) }
            )
        }
        item {
            ShortcutChip(
                label = "Code / Question Hub",
                icon = Icons.Default.Code,
                color = SecondaryTeal,
                onClick = { viewModel.navigateTo(Screen.CustomCodeHub) }
            )
        }
    }
}

@Composable
private fun BoardWorksheetsGridSection(viewModel: HscViewModel) {
    val items = listOf(
        WorksheetItemData(
            topic = GrammarTopic.PREPOSITION,
            title = "Prepositions Worksheet (Q 1–30)",
            bangla = "উপযুক্ত প্রিপজিশন • ৩০টি বোর্ড প্যাসেজ",
            countText = "30 Passages • 300 Questions",
            boardsText = "DB, MB, CB, RB, DjB, JB, CtgB, SB, BB (2022-2025)",
            accentColor = PrimaryBlue
        ),
        WorksheetItemData(
            topic = GrammarTopic.RIGHT_FORM_OF_VERBS,
            title = "Right Form of Verbs (Q 1–15)",
            bangla = "ক্রিয়ার সঠিক রূপ • ১৫টি বোর্ড প্যাসেজ",
            countText = "15 Passages • 210 Questions",
            boardsText = "14 Verbs per Board • Golden Rule Codes (2024-2025)",
            accentColor = SecondaryTeal
        ),
        WorksheetItemData(
            topic = GrammarTopic.SENTENCE_CONNECTORS,
            title = "Sentence Connectors (Q 1–42)",
            bangla = "সংযোজক শব্দ • ৪২টি বোর্ড প্যাসেজ",
            countText = "42 Passages • 580 Questions",
            boardsText = "All Boards (2018-2025) with Logical Categories",
            accentColor = TertiaryAmber
        ),
        WorksheetItemData(
            topic = GrammarTopic.ARTICLE,
            title = "Articles & Cross (Q 1–21)",
            bangla = "আর্টিকেল ও ক্রস • ২১টি বোর্ড প্যাসেজ",
            countText = "21 Passages • 210 Questions",
            boardsText = "HSC Board 2026 to 2016 Board Sets",
            accentColor = CorrectGreen
        )
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items.forEach { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.startWorksheet(item.topic) },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = BorderStroke(1.dp, item.accentColor.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(item.accentColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = item.accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = item.bangla,
                            style = MaterialTheme.typography.bodySmall,
                            color = item.accentColor,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = "${item.countText} • ${item.boardsText}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { viewModel.startWorksheet(item.topic) },
                        colors = ButtonDefaults.buttonColors(containerColor = item.accentColor),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Practice", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

private data class WorksheetItemData(
    val topic: GrammarTopic,
    val title: String,
    val bangla: String,
    val countText: String,
    val boardsText: String,
    val accentColor: Color
)

@Composable
private fun ShortcutChip(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = color.copy(alpha = 0.12f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = color,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    subtitle: String,
    actionText: String?,
    onActionClick: (() -> Unit)?
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (actionText != null && onActionClick != null) {
            Text(
                text = actionText,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable { onActionClick() }
                    .padding(4.dp)
            )
        }
    }
}

@Composable
private fun TopicCard(
    topic: GrammarTopic,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .testTag("topic_card_${topic.id}")
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = topic.marks,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Practice",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = topic.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = topic.banglaTitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = topic.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun BoardExamSetCard(
    examSet: BoardExamSet,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() }
            .testTag("exam_set_${examSet.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PrimaryBlue.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Assignment,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = examSet.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = examSet.boardName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = " • ${examSet.questions.size} Questions • ${examSet.durationMinutes} mins",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(text = "Start", fontSize = 12.sp)
            }
        }
    }
}
