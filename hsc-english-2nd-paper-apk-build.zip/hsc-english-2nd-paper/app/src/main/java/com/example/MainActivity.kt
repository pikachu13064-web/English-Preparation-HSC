package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.Screen
import com.example.ui.screens.BookmarksAndMistakesScreen
import com.example.ui.screens.CodeImportScreen
import com.example.ui.screens.ExamResultScreen
import com.example.ui.screens.ExamScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PracticeScreen
import com.example.ui.screens.RulesScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.HscViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HscAppContent()
                }
            }
        }
    }
}

@Composable
fun HscAppContent(viewModel: HscViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Back handling for sub-screens
    BackHandler(enabled = currentScreen !is Screen.Home) {
        viewModel.navigateBack()
    }

    when (val screen = currentScreen) {
        is Screen.Home -> HomeScreen(viewModel = viewModel)
        is Screen.Practice -> PracticeScreen(viewModel = viewModel)
        is Screen.BoardExam -> ExamScreen(viewModel = viewModel)
        is Screen.WorksheetView -> com.example.ui.screens.WorksheetPracticeScreen(
            topic = screen.topic,
            initialIndex = screen.initialPassageIndex,
            viewModel = viewModel
        )
        is Screen.RulesBook -> RulesScreen(viewModel = viewModel)
        is Screen.BookmarksAndMistakes -> BookmarksAndMistakesScreen(viewModel = viewModel)
        is Screen.CustomCodeHub -> CodeImportScreen(viewModel = viewModel)
        is Screen.Result -> ExamResultScreen(result = screen.result, viewModel = viewModel)
    }
}
