package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.BoardExamSet
import com.example.model.GrammarTopic
import com.example.model.Question
import org.json.JSONArray
import org.json.JSONObject

data class UserStats(
    val totalAnswered: Int = 0,
    val totalCorrect: Int = 0,
    val streakDays: Int = 3,
    val bookmarkedCount: Int = 0,
    val mistakesCount: Int = 0,
    val customQuestionsCount: Int = 0
) {
    val accuracyPercentage: Int
        get() = if (totalAnswered > 0) ((totalCorrect * 100f) / totalAnswered).toInt() else 0
}

class PracticeRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("hsc_english_prefs", Context.MODE_PRIVATE)

    private val customQuestions = mutableListOf<Question>()

    init {
        loadCustomQuestions()
    }

    fun getAllQuestions(): List<Question> {
        return QuestionBankData.allQuestions + customQuestions
    }

    fun getQuestionsForTopic(topic: GrammarTopic): List<Question> {
        return getAllQuestions().filter { it.topic == topic }
    }

    fun getExamSet(id: String): BoardExamSet? {
        val found = QuestionBankData.boardExamSets.find { it.id == id }
        if (found != null && customQuestions.isNotEmpty() && id == "set_all_boards_grand") {
            return found.copy(questions = found.questions + customQuestions)
        }
        return found
    }

    fun getAllBoardSets(): List<BoardExamSet> {
        return QuestionBankData.boardExamSets
    }

    fun getBookmarkedQuestionIds(): Set<String> {
        return prefs.getStringSet("bookmarked_ids", emptySet()) ?: emptySet()
    }

    fun toggleBookmark(questionId: String): Boolean {
        val current = getBookmarkedQuestionIds().toMutableSet()
        val isNowBookmarked = if (current.contains(questionId)) {
            current.remove(questionId)
            false
        } else {
            current.add(questionId)
            true
        }
        prefs.edit().putStringSet("bookmarked_ids", current).apply()
        return isNowBookmarked
    }

    fun isBookmarked(questionId: String): Boolean {
        return getBookmarkedQuestionIds().contains(questionId)
    }

    fun getBookmarkedQuestions(): List<Question> {
        val ids = getBookmarkedQuestionIds()
        return getAllQuestions().filter { it.id in ids }
    }

    fun getMistakeQuestionIds(): Set<String> {
        return prefs.getStringSet("mistake_ids", emptySet()) ?: emptySet()
    }

    fun recordQuestionAttempt(questionId: String, isCorrect: Boolean) {
        val total = prefs.getInt("total_answered", 0) + 1
        val correct = prefs.getInt("total_correct", 0) + if (isCorrect) 1 else 0

        val mistakes = getMistakeQuestionIds().toMutableSet()
        if (isCorrect) {
            mistakes.remove(questionId)
        } else {
            mistakes.add(questionId)
        }

        prefs.edit()
            .putInt("total_answered", total)
            .putInt("total_correct", correct)
            .putStringSet("mistake_ids", mistakes)
            .apply()
    }

    fun getMistakeQuestions(): List<Question> {
        val ids = getMistakeQuestionIds()
        return getAllQuestions().filter { it.id in ids }
    }

    fun getUserStats(): UserStats {
        return UserStats(
            totalAnswered = prefs.getInt("total_answered", 0),
            totalCorrect = prefs.getInt("total_correct", 0),
            streakDays = prefs.getInt("streak_days", 4),
            bookmarkedCount = getBookmarkedQuestionIds().size,
            mistakesCount = getMistakeQuestionIds().size,
            customQuestionsCount = customQuestions.size
        )
    }

    fun addCustomQuestion(question: Question): Boolean {
        customQuestions.add(question)
        saveCustomQuestions()
        return true
    }

    fun deleteCustomQuestion(questionId: String): Boolean {
        val removed = customQuestions.removeAll { it.id == questionId }
        if (removed) {
            saveCustomQuestions()
        }
        return removed
    }

    fun getCustomQuestions(): List<Question> {
        return customQuestions.toList()
    }

    fun importQuestionsFromJson(jsonString: String): Pair<Int, String> {
        try {
            val jsonArray = JSONArray(jsonString.trim())
            var importedCount = 0
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val topicStr = obj.optString("topic", "PREPOSITION").uppercase()
                val topic = try {
                    GrammarTopic.valueOf(topicStr)
                } catch (e: Exception) {
                    GrammarTopic.PREPOSITION
                }

                val optionsArray = obj.getJSONArray("options")
                val options = mutableListOf<String>()
                for (j in 0 until optionsArray.length()) {
                    options.add(optionsArray.getString(j))
                }

                val question = Question(
                    id = "custom_${System.currentTimeMillis()}_$i",
                    topic = topic,
                    questionText = obj.getString("questionText"),
                    contextPassage = obj.optString("contextPassage").takeIf { it.isNotEmpty() },
                    options = options,
                    correctIndex = obj.getInt("correctIndex"),
                    explanation = obj.optString("explanation", "Custom practice item"),
                    ruleHint = obj.optString("ruleHint").takeIf { it.isNotEmpty() },
                    boardTag = obj.optString("boardTag", "User Custom Question"),
                    isCustom = true
                )
                customQuestions.add(question)
                importedCount++
            }
            saveCustomQuestions()
            return Pair(importedCount, "Successfully imported $importedCount question(s)!")
        } catch (e: Exception) {
            return Pair(0, "Error parsing questions JSON: ${e.message}")
        }
    }

    private fun saveCustomQuestions() {
        val array = JSONArray()
        for (q in customQuestions) {
            val obj = JSONObject()
            obj.put("id", q.id)
            obj.put("topic", q.topic.name)
            obj.put("questionText", q.questionText)
            q.contextPassage?.let { obj.put("contextPassage", it) }
            val optionsArr = JSONArray()
            q.options.forEach { optionsArr.put(it) }
            obj.put("options", optionsArr)
            obj.put("correctIndex", q.correctIndex)
            obj.put("explanation", q.explanation)
            q.ruleHint?.let { obj.put("ruleHint", it) }
            q.boardTag?.let { obj.put("boardTag", it) }
            array.put(obj)
        }
        prefs.edit().putString("custom_questions_json", array.toString()).apply()
    }

    private fun loadCustomQuestions() {
        customQuestions.clear()
        val raw = prefs.getString("custom_questions_json", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val topic = try {
                    GrammarTopic.valueOf(obj.getString("topic"))
                } catch (e: Exception) {
                    GrammarTopic.PREPOSITION
                }
                val optArr = obj.getJSONArray("options")
                val opts = mutableListOf<String>()
                for (j in 0 until optArr.length()) {
                    opts.add(optArr.getString(j))
                }
                customQuestions.add(
                    Question(
                        id = obj.getString("id"),
                        topic = topic,
                        questionText = obj.getString("questionText"),
                        contextPassage = obj.optString("contextPassage").takeIf { it.isNotEmpty() },
                        options = opts,
                        correctIndex = obj.getInt("correctIndex"),
                        explanation = obj.getString("explanation"),
                        ruleHint = obj.optString("ruleHint").takeIf { it.isNotEmpty() },
                        boardTag = obj.optString("boardTag", "User Custom Question"),
                        isCustom = true
                    )
                )
            }
        } catch (_: Exception) {
        }
    }
}
