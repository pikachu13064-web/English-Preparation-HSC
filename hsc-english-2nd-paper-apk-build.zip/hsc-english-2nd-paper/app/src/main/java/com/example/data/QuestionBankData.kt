package com.example.data

import com.example.model.BoardExamSet
import com.example.model.GrammarTopic
import com.example.model.Question

object QuestionBankData {

    val allQuestions: List<Question> = listOf(
        // Prepositions
        Question(
            id = "q_prep_1",
            topic = GrammarTopic.PREPOSITION,
            questionText = "The brave freedom fighters fought ___ their last breath to liberate the motherland.",
            options = listOf("till", "for", "against", "with"),
            correctIndex = 0,
            explanation = "'Till' expresses duration up to a particular point in time. 'Fought till one's last breath' is the standard idiom.",
            ruleHint = "Time duration preposition",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_prep_2",
            topic = GrammarTopic.PREPOSITION,
            questionText = "A true gentleman is always polite ___ his behavior towards everyone.",
            options = listOf("in", "at", "with", "by"),
            correctIndex = 0,
            explanation = "One is polite 'in' behavior or speech, or polite 'to' people.",
            ruleHint = "Appropriate preposition with 'polite in'",
            boardTag = "Rajshahi Board 2023"
        ),
        Question(
            id = "q_prep_3",
            topic = GrammarTopic.PREPOSITION,
            questionText = "He is senior ___ me by two years in our college department.",
            options = listOf("to", "than", "from", "of"),
            correctIndex = 0,
            explanation = "Latin comparative adjectives (senior, junior, superior, inferior, prefer) always take 'to', never 'than'.",
            ruleHint = "Senior / Junior + to",
            boardTag = "Cumilla Board 2022"
        ),
        Question(
            id = "q_prep_4",
            topic = GrammarTopic.PREPOSITION,
            questionText = "Smoking is injurious ___ health and leads to fatal diseases.",
            options = listOf("to", "for", "with", "in"),
            correctIndex = 0,
            explanation = "'Injurious' is followed by 'to' (Injurious to health). Similarly: Harmful to, Detrimental to.",
            ruleHint = "Injurious + to",
            boardTag = "Chattogram Board 2023"
        ),

        // Special Words & Phrases
        Question(
            id = "q_sp_1",
            topic = GrammarTopic.SPECIAL_WORDS,
            questionText = "Kazi Nazrul Islam was our national rebel poet. He ___ in Churulia in 1899.",
            options = listOf("was born", "had better", "would rather", "as soon as"),
            correctIndex = 0,
            explanation = "'Was born' is used to refer to someone's birth in a specific year or place.",
            ruleHint = "Historical birth reference",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_sp_2",
            topic = GrammarTopic.SPECIAL_WORDS,
            questionText = "The honest officer ___ resign his post than accept a bribe.",
            options = listOf("would rather", "had better", "let alone", "as if"),
            correctIndex = 0,
            explanation = "'Would rather ... than' indicates preference for one action over another (often showing integrity or dignity).",
            ruleHint = "Would rather + V1 + than",
            boardTag = "Dinajpur Board 2023"
        ),
        Question(
            id = "q_sp_3",
            topic = GrammarTopic.SPECIAL_WORDS,
            questionText = "The poor child cannot even afford a cheap pen, ___ a smartphone for online classes.",
            options = listOf("let alone", "would rather", "as soon as", "was born"),
            correctIndex = 0,
            explanation = "'Let alone' expresses that something is much more impossible than the first stated difficulty.",
            ruleHint = "Impossible comparison",
            boardTag = "Sylhet Board 2023"
        ),
        Question(
            id = "q_sp_4",
            topic = GrammarTopic.SPECIAL_WORDS,
            questionText = "Dark clouds are gathering quickly in the sky. You ___ carry an umbrella with you.",
            options = listOf("had better", "have to", "what's it like", "as though"),
            correctIndex = 0,
            explanation = "'Had better' is used to give urgent, sensible advice in the present/immediate future.",
            ruleHint = "Sensible advice / warning",
            boardTag = "Jashore Board 2022"
        ),
        Question(
            id = "q_sp_5",
            topic = GrammarTopic.SPECIAL_WORDS,
            questionText = "___ an extraterrestrial alien ___? Have you ever imagined its appearance?",
            options = listOf("What does ... look like", "What's it like", "As if", "There"),
            correctIndex = 0,
            explanation = "'What does [Subject] look like?' asks about physical appearance.",
            ruleHint = "Asking about appearance",
            boardTag = "Barishal Board 2023"
        ),

        // Completing Sentences
        Question(
            id = "q_cs_1",
            topic = GrammarTopic.COMPLETING_SENTENCES,
            questionText = "He hurried to the examination hall lest he ___ late for the examination.",
            options = listOf("should be", "would be", "will be", "is"),
            correctIndex = 0,
            explanation = "After 'lest', the clause structure is Subject + should/might + base verb (V1).",
            ruleHint = "Lest + Subject + should + V1",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_cs_2",
            topic = GrammarTopic.COMPLETING_SENTENCES,
            questionText = "Deforestation is destroying our ecology. It is high time we ___ trees massively.",
            options = listOf("planted", "plant", "should plant", "have planted"),
            correctIndex = 0,
            explanation = "'It is high time' + Subject requires Past Indefinite tense (V2) to show urgency.",
            ruleHint = "It is high time + Sub + V2",
            boardTag = "Mymensingh Board 2023"
        ),
        Question(
            id = "q_cs_3",
            topic = GrammarTopic.COMPLETING_SENTENCES,
            questionText = "If you had informed me earlier about the change of schedule, I ___ you at the station.",
            options = listOf("would have met", "would meet", "will meet", "had met"),
            correctIndex = 0,
            explanation = "Third conditional: If + Past Perfect (had + V3), the main clause requires Subject + would/could/might have + Past Participle (V3).",
            ruleHint = "3rd Conditional rule",
            boardTag = "Rajshahi Board 2022"
        ),
        Question(
            id = "q_cs_4",
            topic = GrammarTopic.COMPLETING_SENTENCES,
            questionText = "He speaks so authoritatively as though he ___ everything about space science.",
            options = listOf("knew", "knows", "has known", "will know"),
            correctIndex = 0,
            explanation = "When the first clause is Present Indefinite, the clause after 'as though/as if' takes Past Indefinite (unreal past).",
            ruleHint = "Present Indefinite + as if + Past Indefinite",
            boardTag = "Chattogram Board 2023"
        ),

        // Right Form of Verbs
        Question(
            id = "q_rfv_1",
            topic = GrammarTopic.RIGHT_FORM_OF_VERBS,
            questionText = "The principal, along with all senior teachers, ___ attending the symposium right now.",
            options = listOf("is", "are", "were", "have been"),
            correctIndex = 0,
            explanation = "When two subjects are connected by 'along with', 'as well as', or 'with', the verb agrees with the first subject ('The principal' = singular 'is').",
            ruleHint = "First subject agreement rule",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_rfv_2",
            topic = GrammarTopic.RIGHT_FORM_OF_VERBS,
            questionText = "Students visited the National Museum with a view to ___ historical artifacts.",
            options = listOf("observing", "observe", "observed", "to observe"),
            correctIndex = 0,
            explanation = "The phrase 'with a view to' is always followed by a gerund (Verb + ing).",
            ruleHint = "With a view to + V-ing",
            boardTag = "Cumilla Board 2023"
        ),
        Question(
            id = "q_rfv_3",
            topic = GrammarTopic.RIGHT_FORM_OF_VERBS,
            questionText = "Neither the captain nor the sailors ___ able to control the shipwreck yesterday.",
            options = listOf("were", "was", "is", "are"),
            correctIndex = 0,
            explanation = "With 'neither... nor', the verb agrees with the nearer subject ('the sailors' = plural 'were' in past tense).",
            ruleHint = "Neither... nor proximity agreement",
            boardTag = "Sylhet Board 2023"
        ),
        Question(
            id = "q_rfv_4",
            topic = GrammarTopic.RIGHT_FORM_OF_VERBS,
            questionText = "Had I possessed immense wealth, I ___ free schools across every village.",
            options = listOf("would have established", "would establish", "will establish", "had established"),
            correctIndex = 0,
            explanation = "Inverted third conditional ('Had I possessed' = 'If I had possessed') takes 'would have + V3'.",
            ruleHint = "Inverted 3rd Conditional",
            boardTag = "Rajshahi Board 2023"
        ),

        // Narrative Style
        Question(
            id = "q_nar_1",
            topic = GrammarTopic.NARRATION,
            questionText = "Direct: 'Where did you put my dictionary?' father said to me.\nIndirect transformation:",
            options = listOf(
                "Father asked me where I had put his dictionary.",
                "Father told me where did I put his dictionary.",
                "Father asked me that where I have put his dictionary.",
                "Father enquired whether I put his dictionary."
            ),
            correctIndex = 0,
            explanation = "Wh-question does not take 'that' or 'if'. Past indefinite ('did put') backshifts to past perfect ('had put') in assertive order.",
            ruleHint = "Wh-interrogative backshift",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_nar_2",
            topic = GrammarTopic.NARRATION,
            questionText = "Direct: The teacher said, 'Truth triumphs over falsehood.'\nIndirect transformation:",
            options = listOf(
                "The teacher said that truth triumphs over falsehood.",
                "The teacher said that truth triumphed over falsehood.",
                "The teacher asked if truth triumphs over falsehood.",
                "The teacher warned that truth will triumph."
            ),
            correctIndex = 0,
            explanation = "Universal truths, scientific facts, and habitual actions do not change tense in indirect speech.",
            ruleHint = "Universal truth exception",
            boardTag = "Cumilla Board 2022"
        ),

        // Modifiers
        Question(
            id = "q_mod_1",
            topic = GrammarTopic.MODIFIERS,
            questionText = "Water is an ___ (pre-modify the noun with an adjective) element of human survival.",
            options = listOf("essential", "essentially", "essence", "to essential"),
            correctIndex = 0,
            explanation = "'Pre-modify the noun element' requires an adjective ('essential', 'indispensable', 'vital').",
            ruleHint = "Adjective as pre-modifier",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_mod_2",
            topic = GrammarTopic.MODIFIERS,
            questionText = "A dog ___ (use a present participle phrase to post-modify the noun) rarely bites.",
            options = listOf("barking aloud", "barked aloud", "to bark aloud", "bark"),
            correctIndex = 0,
            explanation = "Present participle phrase is formed with Verb-ing ('barking aloud').",
            ruleHint = "Present participle (V-ing) post-modifier",
            boardTag = "Jashore Board 2023"
        ),
        Question(
            id = "q_mod_3",
            topic = GrammarTopic.MODIFIERS,
            questionText = "The student studied ___ (use an intensifier to pre-modify the adverb 'hard') to secure a scholarship.",
            options = listOf("very", "much", "hardly", "quick"),
            correctIndex = 0,
            explanation = "'Very' and 'extremely' are the most common intensifiers used in HSC modifier questions.",
            ruleHint = "Intensifier usage (very / extremely)",
            boardTag = "Barishal Board 2022"
        ),

        // Sentence Connectors
        Question(
            id = "q_conn_1",
            topic = GrammarTopic.SENTENCE_CONNECTORS,
            questionText = "Trees provide us with oxygen. ___, they absorb harmful carbon dioxide from the atmosphere.",
            options = listOf("Besides", "However", "Otherwise", "Therefore"),
            correctIndex = 0,
            explanation = "'Besides', 'Moreover', or 'Furthermore' connects additional points on the same positive topic.",
            ruleHint = "Additive connectors (Moreover / Besides)",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_conn_2",
            topic = GrammarTopic.SENTENCE_CONNECTORS,
            questionText = "He spent his time idly before the final exam. ___, he could not obtain the expected GPA.",
            options = listOf("As a result", "On the other hand", "Nevertheless", "Although"),
            correctIndex = 0,
            explanation = "'As a result', 'Consequently', or 'Therefore' is used when the sentence expresses a direct consequence.",
            ruleHint = "Cause and result connectors",
            boardTag = "Rajshahi Board 2023"
        ),

        // Synonyms & Antonyms
        Question(
            id = "q_syn_1",
            topic = GrammarTopic.SYNONYM_ANTONYM,
            questionText = "What is the SYNONYM of the word 'Obstinate' (Adjective)?",
            options = listOf("Stubborn", "Flexible", "Docile", "Timid"),
            correctIndex = 0,
            explanation = "'Obstinate' means refusing to change opinions or behavior; synonym is 'Stubborn'. 'Flexible' and 'Docile' are antonyms.",
            ruleHint = "High-frequency HSC Board vocabulary",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_syn_2",
            topic = GrammarTopic.SYNONYM_ANTONYM,
            questionText = "What is the ANTONYM of the word 'Abundance' (Noun)?",
            options = listOf("Scarcity", "Plenty", "Surplus", "Sufficiency"),
            correctIndex = 0,
            explanation = "'Abundance' means a copious quantity. Its opposite is 'Scarcity' (shortage). 'Plenty' and 'Surplus' are synonyms.",
            ruleHint = "Antonym drill",
            boardTag = "Chattogram Board 2023"
        ),
        Question(
            id = "q_syn_3",
            topic = GrammarTopic.SYNONYM_ANTONYM,
            questionText = "What is the SYNONYM of the word 'Diligent'?",
            options = listOf("Hardworking", "Indolent", "Careless", "Lethargic"),
            correctIndex = 0,
            explanation = "'Diligent' means showing steady earnest effort; synonym is 'Hardworking' / 'Industrious'.",
            ruleHint = "Board Exam Vocabulary",
            boardTag = "Dinajpur Board 2022"
        ),

        // Punctuation & Capitalization
        Question(
            id = "q_punc_1",
            topic = GrammarTopic.PUNCTUATION,
            questionText = "Which sentence has the CORRECT punctuation and capitalization for direct dialogue?",
            options = listOf(
                "\"Why are you crying, my child?\" asked the kind traveler.",
                "\"Why are you crying my child\"? asked the kind traveler.",
                "\"why are you crying, My Child?\" asked the kind traveler.",
                "Why are you crying my child? Asked the kind traveler."
            ),
            correctIndex = 0,
            explanation = "Direct speech inside speech marks begins with a capital letter, comma separates the direct address 'my child', and question mark is inside the quote.",
            ruleHint = "Dialogue speech marks & vocative comma",
            boardTag = "Dhaka Board 2023"
        ),
        Question(
            id = "q_punc_2",
            topic = GrammarTopic.PUNCTUATION,
            questionText = "Identify the sentence with CORRECT apostrophe and contraction usage:",
            options = listOf(
                "It's true that the cat chased its own shadow.",
                "Its true that the cat chased it's own shadow.",
                "It's true that the cat chased its' own shadow.",
                "Its true that the cat chased its own shadow."
            ),
            correctIndex = 0,
            explanation = "'It's' = contraction of 'It is'. 'Its' = possessive pronoun (no apostrophe).",
            ruleHint = "It's vs Its distinction",
            boardTag = "Cumilla Board 2023"
        )
    )

    // Curated Board Examination Sets
    val boardExamSets: List<BoardExamSet> = listOf(
        BoardExamSet(
            id = "set_dhaka_2023",
            title = "Dhaka Board 2023 Model Paper",
            boardName = "Dhaka Board",
            year = "2023",
            durationMinutes = 20,
            totalMarks = 25,
            questions = allQuestions.filter { it.boardTag?.contains("Dhaka") == true || it.id in listOf("q_prep_1", "q_sp_1", "q_cs_1", "q_rfv_1", "q_nar_1", "q_mod_1", "q_conn_1", "q_syn_1", "q_punc_1") }
        ),
        BoardExamSet(
            id = "set_rajshahi_2023",
            title = "Rajshahi & Cumilla Combined Mock",
            boardName = "Combined Board",
            year = "2023",
            durationMinutes = 25,
            totalMarks = 25,
            questions = allQuestions.filter { it.boardTag?.contains("Rajshahi") == true || it.boardTag?.contains("Cumilla") == true || it.id in listOf("q_prep_2", "q_prep_3", "q_cs_3", "q_rfv_3", "q_rfv_4", "q_nar_2", "q_conn_2", "q_punc_2") }
        ),
        BoardExamSet(
            id = "set_all_boards_grand",
            title = "All Board Grand Grammar Mock",
            boardName = "All Education Boards",
            year = "Latest Syllabus",
            durationMinutes = 30,
            totalMarks = 30,
            questions = allQuestions
        )
    )
}
