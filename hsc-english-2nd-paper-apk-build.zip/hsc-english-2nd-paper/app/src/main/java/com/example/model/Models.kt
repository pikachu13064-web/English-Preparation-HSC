package com.example.model

enum class GrammarTopic(
    val id: String,
    val title: String,
    val banglaTitle: String,
    val marks: String,
    val description: String,
    val totalAvailable: Int = 10
) {
    ARTICLE(
        id = "articles",
        title = "Articles (A/An/The/✕)",
        banglaTitle = "আর্টিকেল ও ক্রস",
        marks = "5 Marks",
        description = "Definite, indefinite, and zero articles across board exam passages."
    ),
    PREPOSITION(
        id = "preposition",
        title = "Prepositions",
        banglaTitle = "উপযুক্ত প্রিপজিশন",
        marks = "5 Marks",
        description = "Appropriate prepositions and prepositional idioms in board exam contexts."
    ),
    SPECIAL_WORDS(
        id = "special_words",
        title = "Words & Phrases",
        banglaTitle = "বিশেষ শব্দ ও বাক্যাংশ",
        marks = "5 Marks",
        description = "Was born, have to, would rather, had better, let alone, as soon as, what's it like."
    ),
    COMPLETING_SENTENCES(
        id = "completing_sentences",
        title = "Completing Sentences",
        banglaTitle = "বাক্য সম্পূর্ণকরণ",
        marks = "5 Marks",
        description = "Conditionals, so that, lest, it is high time, as if, no sooner had, provided that."
    ),
    RIGHT_FORM_OF_VERBS(
        id = "right_form_of_verbs",
        title = "Right Form of Verbs",
        banglaTitle = "ক্রিয়ার সঠিক রূপ",
        marks = "7 Marks",
        description = "Subject-verb agreement, tenses, active/passive voice, gerunds & participles."
    ),
    NARRATION(
        id = "narration",
        title = "Narrative Style",
        banglaTitle = "উক্তি পরিবর্তন",
        marks = "5 Marks",
        description = "Passage narration, direct to indirect speech conversions and exceptions."
    ),
    MODIFIERS(
        id = "modifiers",
        title = "Modifiers",
        banglaTitle = "মডিফায়ার",
        marks = "5 Marks",
        description = "Pre-modifiers, post-modifiers, present/past participles, intensifiers, appositives."
    ),
    SENTENCE_CONNECTORS(
        id = "sentence_connectors",
        title = "Sentence Connectors",
        banglaTitle = "সংযোজক শব্দ",
        marks = "7 Marks",
        description = "Coordinating & subordinating connectors, transitions and linkers."
    ),
    SYNONYM_ANTONYM(
        id = "synonym_antonym",
        title = "Synonym & Antonym",
        banglaTitle = "সমার্থক ও বিপরীত শব্দ",
        marks = "7 Marks",
        description = "High-frequency HSC vocabulary, contextual word meanings, antonym drills."
    ),
    PUNCTUATION(
        id = "punctuation",
        title = "Punctuation & Capitalization",
        banglaTitle = "বিরামচিহ্ন ও ক্যাপিটালাইজেশন",
        marks = "7 Marks",
        description = "Dialogue speech marks, commas, apostrophes, and capitalization rules."
    )
}

data class Question(
    val id: String,
    val topic: GrammarTopic,
    val questionText: String,
    val contextPassage: String? = null,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val ruleHint: String? = null,
    val boardTag: String? = null,
    val isCustom: Boolean = false
)

data class BoardExamSet(
    val id: String,
    val title: String,
    val boardName: String,
    val year: String,
    val durationMinutes: Int = 20,
    val totalMarks: Int = 25,
    val questions: List<Question>
)

data class PassageBlank(
    val letter: String,
    val prompt: String? = null,
    val answer: String,
    val explanation: String
)

data class PassageWorksheet(
    val id: String,
    val questionNumber: Int,
    val topic: GrammarTopic,
    val sourceBoard: String,
    val rawText: String,
    val blanks: List<PassageBlank>
)

data class GrammarRule(
    val id: String,
    val topic: GrammarTopic,
    val ruleTitle: String,
    val formula: String,
    val banglaExplanation: String,
    val examples: List<RuleExample>
)

data class RuleExample(
    val context: String,
    val incorrectOrPrompt: String,
    val correct: String,
    val note: String? = null
)

data class QuizSessionState(
    val title: String,
    val topic: GrammarTopic?,
    val isExamMode: Boolean,
    val questions: List<Question>,
    val currentIndex: Int = 0,
    val selectedAnswers: Map<Int, Int> = emptyMap(),
    val isSubmitted: Boolean = false,
    val remainingSeconds: Int = 0,
    val bookmarkedIds: Set<String> = emptySet()
)

data class QuizResult(
    val title: String,
    val totalQuestions: Int,
    val correctCount: Int,
    val wrongCount: Int,
    val skippedCount: Int,
    val scorePercentage: Float,
    val topicBreakdown: Map<GrammarTopic, Pair<Int, Int>>,
    val questions: List<Question>,
    val userAnswers: Map<Int, Int>
)

sealed class Screen {
    object Home : Screen()
    data class Practice(val topic: GrammarTopic) : Screen()
    data class BoardExam(val examSetId: String) : Screen()
    data class WorksheetView(val topic: GrammarTopic, val initialPassageIndex: Int = 0) : Screen()
    object RulesBook : Screen()
    object BookmarksAndMistakes : Screen()
    object CustomCodeHub : Screen()
    data class Result(val result: QuizResult) : Screen()
}
