package com.example

import com.example.data.GrammarRulesData
import com.example.data.QuestionBankData
import com.example.model.GrammarTopic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testAllGrammarTopicsCovered() {
        val questions = QuestionBankData.allQuestions
        assertTrue(questions.isNotEmpty())

        val coveredTopics = questions.map { it.topic }.toSet()
        // Ensure core HSC English 2nd paper topics are present
        assertTrue(coveredTopics.contains(GrammarTopic.PREPOSITION))
        assertTrue(coveredTopics.contains(GrammarTopic.SPECIAL_WORDS))
        assertTrue(coveredTopics.contains(GrammarTopic.COMPLETING_SENTENCES))
        assertTrue(coveredTopics.contains(GrammarTopic.RIGHT_FORM_OF_VERBS))
        assertTrue(coveredTopics.contains(GrammarTopic.NARRATION))
        assertTrue(coveredTopics.contains(GrammarTopic.MODIFIERS))
        assertTrue(coveredTopics.contains(GrammarTopic.SENTENCE_CONNECTORS))
        assertTrue(coveredTopics.contains(GrammarTopic.SYNONYM_ANTONYM))
        assertTrue(coveredTopics.contains(GrammarTopic.PUNCTUATION))
    }

    @Test
    fun testQuestionOptionsAndIndicesValid() {
        for (q in QuestionBankData.allQuestions) {
            assertTrue("Question ${q.id} must have at least 2 options", q.options.size >= 2)
            assertTrue(
                "Question ${q.id} correctIndex ${q.correctIndex} must be within options range 0 until ${q.options.size}",
                q.correctIndex in 0 until q.options.size
            )
            assertTrue("Question ${q.id} must have non-empty explanation", q.explanation.isNotBlank())
        }
    }

    @Test
    fun testBoardExamSets() {
        val sets = QuestionBankData.boardExamSets
        assertTrue(sets.isNotEmpty())
        for (s in sets) {
            assertTrue(s.durationMinutes > 0)
            assertTrue(s.questions.isNotEmpty())
        }
    }

    @Test
    fun testGrammarRulesData() {
        val rules = GrammarRulesData.allRules
        assertTrue(rules.isNotEmpty())
        for (r in rules) {
            assertTrue(r.formula.isNotBlank())
            assertTrue(r.banglaExplanation.isNotBlank())
            assertTrue(r.examples.isNotEmpty())
        }
    }
}
